# GUI Quiz Application using Tkinter and Open Trivia DB

![Banner](images/banner.png)

Read The Blog on iRead: https://ashutoshkrris.hashnode.dev/how-to-build-a-gui-quiz-application-using-tkinter-and-open-trivia-db

Download for Windows [here](https://github.com/ashutoshkrris/GUI-Quiz-Tkinter/raw/master/quiz.exe)


### Screenshots

![Screenshot 1](images/ss1.png)
<br>
![Screenshot 2](images/ss2.png)
<br>
![Screenshot 3](images/ss3.png)
<br>
![Screenshot 4](images/ss4.png)
