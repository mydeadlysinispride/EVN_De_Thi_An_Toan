from question_model import Question
from quiz_brain import QuizBrain
from quiz_ui import QuizInterface
from random import shuffle
import html

import json

# Assuming your JSON file is named 'questions_bank.json' and is in the same directory as your Python script
file_path = 'questions_bank.json'

with open(file_path, 'r', encoding='utf-8') as f:
    question_data = json.load(f)

# Now 'data' contains the contents of your JSON file

question_bank = []
shuffle(question_data)
for question in question_data:
    # Convert integer values to strings before unescaping
    choices = [html.unescape(str(question[key])) for key in ['A', 'B', 'C', 'D']]
    correct_answer = html.unescape(str(question["ĐÁP ÁN ĐÚNG"]))
    question_text = html.unescape(question["CÂU HỎI"])
    
    # Find index of correct answer in original choices list
    correct_index = ['A', 'B', 'C', 'D'].index(correct_answer)
    
    # Shuffle choices
    shuffled_choices = choices[:]
    shuffle(shuffled_choices)
    
    # Update correct answer with its position in shuffled list
    correct_answer = choices[correct_index]
    
    new_question = Question(question_text, correct_answer, shuffled_choices)
    question_bank.append(new_question)


quiz = QuizBrain(question_bank)

quiz_ui = QuizInterface(quiz)

print("You've completed the quiz")
print(f"Your final score was: {quiz.score}/{quiz.question_no}")
